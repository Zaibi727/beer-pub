import React from 'react';

class Accounting extends React.Component {
    render() { 
        return ( 
            <div>
                <h2>Accounting</h2>
            </div>
         );
    }
}
 
export default Accounting;