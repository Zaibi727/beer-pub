import React from 'react';

class Plans extends React.Component {
    render() { 
        return ( 
            <div>
                <h2>Plans</h2>
            </div>
         );
    }
}
 
export default Plans;