import React from 'react';

class Team extends React.Component {
    render() { 
        return ( 
            <div>
                <h2>Team</h2>
            </div>
         );
    }
}
 
export default Team;